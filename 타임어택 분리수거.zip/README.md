# 분리수거 대작전 ♻️

45초 동안 쓰레기를 올바른 수거함에 넣어 점수와 콤보를 쌓는 브라우저 미니게임입니다.

## 실행

`index.html`을 브라우저에서 열면 바로 실행됩니다. 별도의 설치나 빌드가 필요 없습니다.

## GitHub Pages 배포

이 폴더의 파일 4개를 기존 저장소의 `recycle-rush` 폴더에 업로드하세요. 게임 주소는 다음 형식입니다.

`https://exit01376-ai.github.io/Zachwi-on-tools/recycle-rush/`

## 조작법

- 쓰레기 클릭 후 수거함 클릭
- 키보드 1~4번 키
- 모바일 및 마우스 드래그

## 파일

- `index.html`: 게임
- `README.md`: 안내
- `game.json`: 게임 정보
- `thumbnail.png`: 대표 이미지
